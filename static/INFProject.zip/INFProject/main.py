#############
## IMPORTS ##
#############

from flask import request, jsonify, render_template
from config import app, get_db_connection
import mysql.connector
from datetime import datetime

############
## ROUTES ##
############

## TEST CONNECTION TO DATABASE
##############################
@app.route('/index.html', methods=['GET'])
def test_connection():
    try:
        # Establish database connection
        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)
        
        # Execute queries
        # Query to group sales by month
        query = '''
            SELECT 
                DATE_FORMAT(SellingDate, '%Y-%m') AS month,  
                SUM(Price) AS total_sales_price
            FROM 
                sales
            GROUP BY 
                DATE_FORMAT(SellingDate, '%Y-%m')
        '''
        
        # Execute the query
        cursor.execute(query)
        sales_data = cursor.fetchall()


        
        # Close the connection
        cursor.close()
        connection.close()
        
        # Return as JSON response
        #return jsonify(data)
        return render_template('index.html',sales_data=sales_data)
    
    except mysql.connector.Error as err:
        return jsonify({"error": str(err)}), 500

## FORM
#########

@app.route('/forms/<tablename>/<action>', methods=['GET'])
def form(tablename, action):
    # List of available tables
    tables = ['customers', 'employee', 'inventory', 'purchasing', 'sales']
    
    # Check if the table name exists in the list
    if tablename in tables:
        # Render the respective form template based on the table name
        return render_template(f'forms{tablename}.html', tablename=tablename, action=action)
    else:
        # If table name is not found, return a 404 error or redirect to another page
        return "Table not found", 404


## CREATE
#########
@app.route('/insert/<string:table_name>', methods=['POST'])
def insert_to_table_name(table_name):
    try:
        # Establish database connection
        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)

        # Send a request for data from frontend (using form data)
        data = request.form  # Now expecting form data

        # Get columns fields of table
        query = "SHOW COLUMNS FROM " + table_name
        cursor.execute(query)
        table_info = cursor.fetchall()

        # Same logic for inserting
        new_insert = {}
        for column in table_info:
            Field = column.get("Field")
            Type = column.get("Type")
            if 'ID' not in Field and 'DateTime' not in Field:
                if 'int' in Type:
                    new_insert.update({Field: int(data.get(Field))})
                elif 'decimal' in Type:
                    new_insert.update({Field: float(data.get(Field))})
                elif 'varchar' in Type or 'text' in Type:
                    new_insert.update({Field: data.get(Field)})
                elif 'date' in Type:
                    date_obj = datetime.strptime(data.get(Field), '%Y-%m-%d')
                    sql_date = date_obj.strftime('%Y-%m-%d')
                    new_insert.update({Field: sql_date})

        # Execute query and commit
        if table_name == 'inventory':
            cursor.execute('''INSERT INTO inventory 
                              (Name, Description, SKU, Model, Qty, Location, RawProd)
                              VALUES (%s, %s, %s, %s, %s, %s, %s)''',
                           [new_insert.get('Name'),
                            new_insert.get('Description'),
                            new_insert.get('SKU'),
                            new_insert.get('Model'),
                            new_insert.get('Qty'),
                            new_insert.get('Location'),
                            new_insert.get('RawProd')])
            
        if (table_name == 'purchasing'):
            cursor.execute('''INSERT INTO purchasing 
                           (PurchasingInvoiceNum, ProductName, Price, Model, SKU, Qty, PurchasingDate)
                           VALUES (%s, %s, %s, %s, %s, %s, %s)''',
                           [new_insert.get('PurchasingInvoiceNum'),
                            new_insert.get('ProductName'),
                            new_insert.get('Price'),
                            new_insert.get('Model'),
                            new_insert.get('SKU'),
                            new_insert.get('Qty'),
                            new_insert.get('PurchasingDate')])
        
        connection.commit()
        cursor.close()
        connection.close()
        return render_template('success.html')

    except Exception as e:
        return jsonify({'error': str(e)}), 500
            
    


## READ
#######
@app.route('/table', methods=['GET'])
def get_table_names():
    try:
        # Establish database connection
        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)
        
        # Execute query
        query = "show tables"
        cursor.execute(query)
        
        data = cursor.fetchall()
        
        # Close the connection
        cursor.close()
        connection.close()
        
        # Return as JSON response
        return jsonify(data)
    
    except mysql.connector.Error as err:
        return jsonify({"error": str(err)}), 500

@app.route('/table/<string:table_name>', methods=['GET'])
def get_table_data(table_name):
    try:
        # Establish database connection
        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)
        
        # Execute query
        query = "SELECT * FROM " + table_name
        cursor.execute(query)
        
        data = cursor.fetchall()

        # Get the column names
        column_names = cursor.column_names
        
        # Close the connection
        cursor.close()
        connection.close()
        
        # Return as JSON response
        return  render_template('showtables.html',data=data, columns=column_names,table_name=table_name)
    
    except mysql.connector.Error as err:
        return jsonify({"error": str(err)}), 500
    

## UPDATE
#########
# Sample response.json
# {
#   value: [v1, v2, v3, ..., vN], 
#   condition: "fN = x"
# }
@app.route('/update/<string:table_name>', methods=['POST'])
def update_to_table_name(table_name):
    
    try:
        # Establish database connection
        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)

        # Send a request for data from frontend
        data = request.json
        print("Received Data:", data)
        set_value = data.get("value")
        condition_value = data.get("condition")

        if set_value is None:
            return jsonify({"error": "No data received"}), 400
        
        # Get Field and Type of table columns
        query = "SHOW COLUMNS FROM " + table_name
        cursor.execute(query)
        table_info = cursor.fetchall()
        column_fields = []
        column_types = []

        for column in table_info:
            column_fields.append(column.get("Field"))
            column_types.append(column.get("Type"))

        table_info = {
            "Field": column_fields,
            "Type": column_types
        }

        # Match set_value to correct data type
        # sample set_value = [v1, v2, NA, v4, ..., vN]
        for i in range(len(column_types)):
            if (set_value[i] != 'NA'):
                if ('int' in column_types[i]):
                    set_value[i] = int(set_value[i])
                elif ('text' in column_types[i] or 'char' in column_types[i]):
                    set_value[i] = str(set_value[i])
                elif ('date' in column_types[i]):
                    date_obj = datetime.strptime(set_value[i], '%Y-%m-%d')
                    sql_date = date_obj.strftime('%Y-%m-%d')
                    set_value[i] = sql_date

            # Match NA value to field and type
            if (set_value[i] == 'NA'):
                column_fields[i] = 'NA'
                column_types[i] = 'NA'

        # Clear any NA from all arrays
        set_value = [item for item in set_value if item != 'NA']
        column_fields = [item for item in column_fields if item != 'NA']
        column_types = [item for item in column_types if item != 'NA']

        query = f"UPDATE {table_name} SET " + ", ".join([f"{field} = %s" for field in column_fields]) + f" WHERE {condition_value}"
        print(query)
        cursor.execute(query, set_value)

        connection.commit()
            
        # Close the connectione and return
        cursor.close()
        connection.close()
        return render_template('success.html')
    
    except mysql.connector.Error as err:
        return jsonify({"error": str(err)}), 500


## DELETE
#########
## ROUTE --> DELETE ##
# Sample response.json
# {
#   condition: "fN = x"
# }
@app.route('/delete/<string:table_name>', methods=['POST'])
def delete_from_table_name(table_name):
    try:
        # Establish database connection
        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)

        # Get data from the form
        condition_field = request.form.get('condition_field')
        condition_value = request.form.get('condition_value')

        # Generate and execute query
        query = f"DELETE FROM {table_name} WHERE {condition_field} = %s"
        cursor.execute(query, (condition_value,))

        connection.commit()

        # Close the connection
        cursor.close()
        connection.close()

        # Redirect to success page
        return render_template('success.html')
    
    except mysql.connector.Error as err:
        return jsonify({"error": str(err)}), 500

## ROUTE --> BUILD ##
# Sample response.json
# {
#     Model: "x",
#     Qty: y
# }
@app.route('/build', methods=['POST'])
def build_product():
    try:
        # Establish database connection
        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)

        # Send a request for data from frontend
        data = request.json
        product_model = data.get('Model')
        build_qty = data.get('Qty')
        build_qty = int(build_qty)

        # Building recipe for products {Product model: [ [component_model], [no. of components] ]}
        recipe = {
            'BS-400': [['SD-100', 'SC-700', 'PCB-11', 'PC-300', 'CCB-500', 'BAT-5000'], [1,1,1,1,1,1]],
            'BS-600': [['SD-200', 'SC-700', 'PCB-11', 'PC-300', 'CCB-500', 'BAT-5000'], [1,2,1,1,1,1]],
            'BS-650': [['SD-300', 'SC-800', 'PCB-12', 'PC-300', 'CCB-700', 'BAT-5000'], [2,2,1,1,1,2]],
            'PC-5000': [['BAT-5000', 'CCB-500', 'PC-200'], [1,1,1]],
            'PC-10000': [['BAT-10K', 'CCB-700', 'PC-200'], [1,1,1]],
        }

        # Generate and execute query
        components, recipe_qty = recipe[product_model]
        conditions = []
        for component, qty in zip(components, recipe_qty):
            conditions.append(f"(Model = '{component}' AND Qty >= {build_qty*qty})")

        condition_query = " OR ".join(conditions)
        query = f"SELECT Model, Qty FROM inventory WHERE {condition_query}"

        cursor.execute(query)
        fetch = cursor.fetchall()

        # Check if components are sufficient for build
        if(len(fetch) == len(components)): check = True
        else: check = False

        # Update inventory
        if(check):

            # Get original qty of product from inventory
            query = f"SELECT qty FROM inventory WHERE Model = '{product_model}'"
            cursor.execute(query)
            fetch = cursor.fetchall()[0]
            original_qty = fetch.get("qty")

            # Update qty of product to new quantity
            query = f"UPDATE inventory SET Qty = {original_qty+build_qty} WHERE Model = '{product_model}'"
            cursor.execute(query)

            # Get original qty of components    
            conditions = []
            for component in components:
                conditions.append(f"Model = '{component}'")
            condition_query = " OR ".join(conditions)

            query = f"SELECT Model, qty FROM inventory WHERE ({condition_query})"
            cursor.execute(query)
            fetch = cursor.fetchall()

            # Update qty of components to new quantity            
            conditions = []
            models = []
            for component in fetch:
                model = component.get("Model")
                qty = component.get("qty") - build_qty

                conditions.append(f"WHEN Model = '{model}' THEN {qty}")
                models.append(f"'{model}'")

            condition_query = " ".join(conditions)
            model_query = ", ".join(models)
            
            query = f"UPDATE inventory SET Qty = CASE {condition_query} END WHERE Model IN ({model_query})"
            cursor.execute(query)

        # Execute and commit query
        connection.commit()
            
        # Close the connectione and return
        cursor.close()
        connection.close()
        return render_template('success.html')
    
    except mysql.connector.Error as err:
        return jsonify({"error": str(err)}), 500
    

## ROUTE --> CHECK ##
@app.route('/check_required/', methods=['GET'])
def purchased_product():
    try:
        # Establish database connection
        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)

        # Search for incompleted sales info
        # Returns {
        #   "Model": "x"
        #   "Needed": y
        #   "Available": z
        # }
        query = '''SELECT sales.Model, COUNT(*) AS Needed, inventory.Qty AS Available
            FROM sales
            LEFT JOIN inventory ON sales.Model = inventory.Model
            WHERE Completed = 0
            GROUP BY sales.Model'''
        cursor.execute(query)
        fetch = cursor.fetchall()
        
        # Compares Needed qty to Available qty and generates a report
        # {
        #   "Model": [
        #     "BAT-3000",
        #     "BS-400",
        #     "BS-600",
        #     "BS-650",
        #     "PC-10000",
        #     "PC-5000",
        #     "USB-009" ]
        #   "Sufficient": [1, 0, ..., 0]     # 1 = sufficient, 0 = insufficient
        #   "Build_qty": [0, x, ..., y]      # How many more to build, if sufficient then 0
        # }

        data = {
            "Model": [],
            "Sufficient": [],
            "Build_qty": []
        }
        Model_list = []
        Sufficient_list = []
        Build_qty_list = []
        for product in fetch:
            Model_list.append(product.get("Model"))
            need = product.get("Needed")
            avail = product.get("Available")

            if (need > avail):
                Sufficient_list.append(0)
                Build_qty_list.append(need-avail)

            elif (avail >= need):
                Sufficient_list.append(1)
                Build_qty_list.append(0)
        
        data.update({"Model": Model_list})
        data.update({"Sufficient": Sufficient_list})
        data.update({"Build_qty": Build_qty_list})

        # Close the connectione and return
        cursor.close()
        connection.close()
        return jsonify(data)
    
    except mysql.connector.Error as err:
        return jsonify({"error": str(err)}), 500
    
    

@app.route('/success', methods=['GET'])
def success():
    # Render the success.html template
    return render_template('success.html')





##########
## MAIN ##
##########
if __name__ == '__main__':
    app.run(debug=True)